<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.3" name="BgTilePattern" tilewidth="8" tileheight="8" tilecount="128" columns="16">
 <image source="BgTilePattern.png" width="128" height="64"/>
</tileset>
